import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();
import authRoutes from './routes/auth.js';
import produceRoutes from './routes/produce.js';
import favoritesRoutes from './routes/favorites.js';
import inquiryRoutes from './routes/inquiries.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());
app.get('/api/health', (_req,res) => res.json({ status: 'ok', app: 'FarmConnect API' }));
app.use('/api/auth', authRoutes);
app.use('/api/produce', produceRoutes);
app.use('/api/favorites', favoritesRoutes);
app.use('/api/inquiries', inquiryRoutes);
app.use((err,_req,res,_next) => {
  console.error(err);
  res.status(500).json({ message: 'Unexpected server error.' });
});
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`FarmConnect API running on port ${port}`));
