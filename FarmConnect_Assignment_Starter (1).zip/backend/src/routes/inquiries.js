import { Router } from 'express';
import db from '../db.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
router.use(authenticate);

router.post('/', async (req,res) => {
  try {
    const { produce_id, message } = req.body;
    if (!produce_id || !message?.trim()) return res.status(400).json({ message: 'Listing and message are required.' });
    if (message.trim().length > 1000) return res.status(400).json({ message: 'Message must be 1000 characters or fewer.' });
    const [p] = await db.query('SELECT id,farmer_id FROM produce WHERE id=?', [produce_id]);
    if (!p.length) return res.status(404).json({ message: 'Produce listing not found.' });
    if (p[0].farmer_id === req.user.id) return res.status(403).json({ message: 'You cannot inquire about your own listing.' });
    const [result] = await db.query('INSERT INTO inquiries (buyer_id,produce_id,message) VALUES (?,?,?)',
      [req.user.id,produce_id,message.trim()]);
    res.status(201).json({ id: result.insertId, message: 'Inquiry sent to the farmer.' });
  } catch { res.status(500).json({ message: 'Could not send inquiry.' }); }
});

router.get('/received', async (req,res) => {
  try {
    if (req.user.role !== 'farmer') return res.status(403).json({ message: 'Only farmers can view received inquiries.' });
    const [rows] = await db.query(`SELECT i.*, p.name AS produce_name, b.name AS buyer_name, b.email AS buyer_email
      FROM inquiries i JOIN produce p ON p.id=i.produce_id JOIN users b ON b.id=i.buyer_id
      WHERE p.farmer_id=? ORDER BY i.created_at DESC`, [req.user.id]);
    res.json(rows);
  } catch { res.status(500).json({ message: 'Could not load inquiries.' }); }
});
export default router;
