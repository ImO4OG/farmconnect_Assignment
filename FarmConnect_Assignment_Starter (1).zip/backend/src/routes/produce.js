import { Router } from 'express';
import db from '../db.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(`SELECT p.*, u.name AS farmer_name FROM produce p
      JOIN users u ON u.id=p.farmer_id ORDER BY p.created_at DESC`);
    res.json(rows);
  } catch { res.status(500).json({ message: 'Could not load produce.' }); }
});

router.post('/', authenticate, requireRole('farmer'), async (req, res) => {
  try {
    const { name, description='', quantity, unit, price, location } = req.body;
    if (!name?.trim() || !unit?.trim() || !location?.trim() ||
        !Number.isFinite(Number(quantity)) || Number(quantity) <= 0 ||
        !Number.isFinite(Number(price)) || Number(price) < 0)
      return res.status(400).json({ message: 'Enter a name, positive quantity, valid price, unit and location.' });
    const [result] = await db.query(`INSERT INTO produce (farmer_id,name,description,quantity,unit,price,location)
      VALUES (?,?,?,?,?,?,?)`, [req.user.id,name.trim(),description.trim(),Number(quantity),unit.trim(),Number(price),location.trim()]);
    res.status(201).json({ id: result.insertId, message: 'Produce listing created.' });
  } catch { res.status(500).json({ message: 'Could not create listing.' }); }
});

router.delete('/:id', authenticate, requireRole('farmer'), async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM produce WHERE id=? AND farmer_id=?', [req.params.id, req.user.id]);
    if (!result.affectedRows) return res.status(404).json({ message: 'Listing not found or you do not own it.' });
    res.json({ message: 'Listing deleted.' });
  } catch { res.status(500).json({ message: 'Could not delete listing.' }); }
});
export default router;
