import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../db.js';

const router = Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    if (!name?.trim() || !email?.trim() || !password || !['farmer','buyer'].includes(role))
      return res.status(400).json({ message: 'Name, email, password and valid role are required.' });
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters.' });
    const [existing] = await db.query('SELECT id FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (existing.length) return res.status(409).json({ message: 'This email is already registered.' });
    const hash = await bcrypt.hash(password, 10);
    const [result] = await db.query('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)',
      [name.trim(), email.toLowerCase().trim(), hash, role]);
    const user = { id: result.insertId, name: name.trim(), email: email.toLowerCase().trim(), role };
    const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: '1d' });
    res.status(201).json({ token, user });
  } catch (e) { res.status(500).json({ message: 'Could not register account.' }); }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password are required.' });
    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email.toLowerCase().trim()]);
    if (!rows.length || !(await bcrypt.compare(password, rows[0].password_hash)))
      return res.status(401).json({ message: 'Incorrect email or password.' });
    const u = rows[0];
    const user = { id: u.id, name: u.name, email: u.email, role: u.role };
    const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: '1d' });
    res.json({ token, user });
  } catch { res.status(500).json({ message: 'Could not sign in.' }); }
});
export default router;
