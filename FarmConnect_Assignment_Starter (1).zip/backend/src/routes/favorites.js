import { Router } from 'express';
import db from '../db.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
router.use(authenticate);

router.get('/', async (req,res) => {
  try {
    const [rows] = await db.query(`SELECT p.*, u.name AS farmer_name FROM favorites f
      JOIN produce p ON p.id=f.produce_id JOIN users u ON u.id=p.farmer_id
      WHERE f.user_id=? ORDER BY f.created_at DESC`, [req.user.id]);
    res.json(rows);
  } catch { res.status(500).json({ message: 'Could not load favorites.' }); }
});

router.post('/:produceId', async (req,res) => {
  try {
    const [p] = await db.query('SELECT id FROM produce WHERE id=?', [req.params.produceId]);
    if (!p.length) return res.status(404).json({ message: 'Produce listing does not exist.' });
    await db.query('INSERT IGNORE INTO favorites (user_id,produce_id) VALUES (?,?)', [req.user.id,req.params.produceId]);
    res.status(201).json({ message: 'Added to favorites.' });
  } catch { res.status(500).json({ message: 'Could not save favorite.' }); }
});

router.delete('/:produceId', async (req,res) => {
  try {
    await db.query('DELETE FROM favorites WHERE user_id=? AND produce_id=?', [req.user.id,req.params.produceId]);
    res.json({ message: 'Removed from favorites.' });
  } catch { res.status(500).json({ message: 'Could not remove favorite.' }); }
});
export default router;
