import React, { useEffect, useState } from 'react';
import api from './api';

export default function App() {
  const [user,setUser] = useState(JSON.parse(localStorage.getItem('farmconnect_user') || 'null'));
  const [mode,setMode] = useState('login');
  const [message,setMessage] = useState('');
  const [listings,setListings] = useState([]);
  const [favorites,setFavorites] = useState([]);
  const [inquiries,setInquiries] = useState([]);
  const [tab,setTab] = useState('market');
  const [auth,setAuth] = useState({name:'',email:'',password:'',role:'buyer'});
  const [form,setForm] = useState({name:'',description:'',quantity:'',unit:'kg',price:'',location:''});
  const [inquiry,setInquiry] = useState({produce_id:'',message:''});

  async function loadListings() {
    try { const {data}=await api.get('/produce'); setListings(data); }
    catch(e) { setMessage(e.response?.data?.message || 'Could not connect to API. Start backend and MySQL.'); }
  }
  async function loadFavorites() {
    if (!user) return;
    try { const {data}=await api.get('/favorites'); setFavorites(data); } catch {}
  }
  async function loadInquiries() {
    if (user?.role !== 'farmer') return;
    try { const {data}=await api.get('/inquiries/received'); setInquiries(data); } catch {}
  }
  useEffect(()=>{ loadListings(); },[]);
  useEffect(()=>{ loadFavorites(); loadInquiries(); },[user]);

  async function submitAuth(e) {
    e.preventDefault(); setMessage('');
    try {
      const endpoint=mode==='register'?'/auth/register':'/auth/login';
      const payload=mode==='register'?auth:{email:auth.email,password:auth.password};
      const {data}=await api.post(endpoint,payload);
      localStorage.setItem('farmconnect_token',data.token);
      localStorage.setItem('farmconnect_user',JSON.stringify(data.user));
      setUser(data.user); setMessage(`Welcome, ${data.user.name}!`);
    } catch(e) { setMessage(e.response?.data?.message || 'Authentication failed.'); }
  }
  function logout() {
    localStorage.removeItem('farmconnect_token'); localStorage.removeItem('farmconnect_user');
    setUser(null); setFavorites([]); setInquiries([]); setMessage('You have signed out.');
  }
  async function createListing(e) {
    e.preventDefault(); setMessage('');
    try { await api.post('/produce',form); setForm({name:'',description:'',quantity:'',unit:'kg',price:'',location:''}); setMessage('Listing created.'); await loadListings(); }
    catch(e) { setMessage(e.response?.data?.message || 'Could not create listing.'); }
  }
  async function toggleFavorite(id) {
    const saved=favorites.some(x=>x.id===id);
    try {
      if(saved) await api.delete(`/favorites/${id}`); else await api.post(`/favorites/${id}`);
      await loadFavorites(); setMessage(saved?'Removed from favorites.':'Saved to favorites.');
    } catch(e) { setMessage(e.response?.data?.message || 'Please sign in to save favorites.'); }
  }
  async function sendInquiry(e) {
    e.preventDefault();
    try { await api.post('/inquiries',inquiry); setInquiry({produce_id:'',message:''}); setMessage('Inquiry sent.'); }
    catch(e) { setMessage(e.response?.data?.message || 'Could not send inquiry.'); }
  }
  async function deleteListing(id) {
    try { await api.delete(`/produce/${id}`); setMessage('Listing deleted.'); await loadListings(); }
    catch(e) { setMessage(e.response?.data?.message || 'Could not delete listing.'); }
  }

  const shown=tab==='favorites'?favorites:listings;
  return <div className="app">
    <header><div className="brand">🌱 FarmConnect</div><div className="headerRight">{user?<><span>{user.name} · {user.role}</span><button className="light" onClick={logout}>Sign out</button></>:<span>Connect farmers and buyers</span>}</div></header>
    <section className="hero"><p className="eyebrow">LOCAL AGRICULTURE MARKETPLACE</p><h1>Fresh produce.<br/><span>Closer connections.</span></h1><p>Discover farm produce and connect directly with farmers.</p></section>
    {message && <div className="notice" role="status">{message}<button onClick={()=>setMessage('')} aria-label="Close">×</button></div>}
    {!user && <section className="auth card"><h2>{mode==='login'?'Sign in':'Create an account'}</h2><form onSubmit={submitAuth}>
      {mode==='register'&&<label>Full name<input required value={auth.name} onChange={e=>setAuth({...auth,name:e.target.value})}/></label>}
      <label>Email<input type="email" required value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})}/></label>
      <label>Password<input type="password" minLength="6" required value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})}/></label>
      {mode==='register'&&<label>Account type<select value={auth.role} onChange={e=>setAuth({...auth,role:e.target.value})}><option value="buyer">Buyer</option><option value="farmer">Farmer</option></select></label>}
      <button className="primary">{mode==='login'?'Sign in':'Register'}</button>
    </form><p className="switch">{mode==='login'?'New here?':'Already registered?'} <button className="link" onClick={()=>setMode(mode==='login'?'register':'login')}>{mode==='login'?'Create account':'Sign in'}</button></p></section>}
    <main>
      <div className="tabs"><button className={tab==='market'?'active':''} onClick={()=>setTab('market')}>Market</button><button className={tab==='favorites'?'active':''} onClick={()=>{setTab('favorites');loadFavorites();}}>Favorites</button>{user?.role==='farmer'&&<button className={tab==='add'?'active':''} onClick={()=>setTab('add')}>Add produce</button>}{user?.role==='farmer'&&<button className={tab==='inquiries'?'active':''} onClick={()=>{setTab('inquiries');loadInquiries();}}>Inquiries</button>}</div>
      {tab==='add'&&user?.role==='farmer'&&<section className="card"><h2>Add a produce listing</h2><form className="listingForm" onSubmit={createListing}>
        <label>Produce name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="e.g. Fresh tomatoes"/></label>
        <label>Description<input value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Quality and details"/></label>
        <div className="two"><label>Quantity<input type="number" min="0.01" step="0.01" required value={form.quantity} onChange={e=>setForm({...form,quantity:e.target.value})}/></label><label>Unit<select value={form.unit} onChange={e=>setForm({...form,unit:e.target.value})}><option>kg</option><option>bag</option><option>crate</option><option>piece</option><option>tonne</option></select></label></div>
        <label>Price (UGX per unit)<input type="number" min="0" step="1" required value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></label>
        <label>Location<input required value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="e.g. Mukono"/></label>
        <button className="primary">Publish listing</button>
      </form></section>}
      {tab==='inquiries'&&user?.role==='farmer'&&<section className="card"><h2>Inquiries received</h2>{inquiries.length===0?<p>No inquiries yet.</p>:inquiries.map(i=><article className="inquiry" key={i.id}><b>{i.produce_name}</b><p>{i.message}</p><small>From {i.buyer_name} ({i.buyer_email}) · {new Date(i.created_at).toLocaleString()}</small></article>)}</section>}
      {(tab==='market'||tab==='favorites')&&<><div className="sectionTitle"><div><h2>{tab==='market'?'Available produce':'Your favorites'}</h2><p>{shown.length} listing{shown.length===1?'':'s'}</p></div></div>{shown.length===0?<div className="empty card">{tab==='favorites'?'No favorites saved yet. Browse the market and tap ♡.':'No produce listings yet. A farmer can add the first listing.'}</div>:<div className="cards">{shown.map(p=><article className="produce card" key={p.id}><div className="produceIcon">🌾</div><div className="produceTop"><span className="tag">{p.location}</span>{user&&<button className="heart" onClick={()=>toggleFavorite(p.id)} title="Toggle favorite">{favorites.some(x=>x.id===p.id)?'♥':'♡'}</button>}</div><h3>{p.name}</h3><p className="desc">{p.description||'Fresh farm produce available.'}</p><div className="price">UGX {Number(p.price).toLocaleString()} <small>/ {p.unit}</small></div><p className="quantity">{p.quantity} {p.unit} available</p><p className="farmer">👨‍🌾 {p.farmer_name}</p>{user?.role==='buyer'&&<form onSubmit={sendInquiry} className="inquiryForm"><textarea required maxLength="1000" placeholder="Write an inquiry to the farmer…" value={inquiry.produce_id===String(p.id)?inquiry.message:''} onChange={e=>setInquiry({produce_id:String(p.id),message:e.target.value})}/><button className="primary" disabled={inquiry.produce_id!==String(p.id)||!inquiry.message.trim()}>Send inquiry</button></form>}{user?.role==='farmer'&&user.id===p.farmer_id&&<button className="danger" onClick={()=>deleteListing(p.id)}>Delete my listing</button>}</article>)}</div>}</>}
    </main>
    <footer>FarmConnect · Learning project for Web and Mobile Application Development</footer>
  </div>;
}
