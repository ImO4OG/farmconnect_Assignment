# FarmConnect Assignment Starter

A beginner-friendly full-stack FarmConnect application with React + Vite, Express, and MySQL.

## Features implemented
1. Farmer accounts (register/login using JWT).
2. Produce listings: farmers can create listings; logged-in users can browse.
3. Database-backed favorites: saved for the logged-in user.
4. Buyer inquiries: send inquiries on produce; farmer can view received inquiries.

The assignment asks for at least three distinct new features. Confirm these are genuinely new compared with the lecturer's starting repositories before submitting. This is a starter implementation and not a replacement for the lecturer's matching repositories.

## Requirements
- Node.js 18+
- MySQL 8+ (or compatible MariaDB)
- npm

## Database
1. Create a database in MySQL:
   ```sql
   CREATE DATABASE farmconnect;
   ```
2. Import `backend/database/schema.sql` using MySQL Workbench or:
   ```bash
   mysql -u root -p farmconnect < backend/database/schema.sql
   ```

## Backend
```bash
cd backend
copy .env.example .env
npm install
npm run dev
```
Edit `.env` and enter your MySQL username/password and a long JWT secret.

## Frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Visit the local URL Vite displays (usually http://localhost:5173).

## Use
- Register an account. Choose Farmer to add produce; choose Buyer to browse and send inquiries.
- Sign in, browse produce, and save favorites.
- Farmers can view inquiries received for their listings.

## Safety / academic notes
- `.env` is not included. Never commit real credentials.
- This code is a learning scaffold. Check, run, test, and understand it. Keep original attribution when using lecturer repositories.
- For the assignment, fork the lecturer's FarmConnect frontend and backend repos and merge/adapt the features into those codebases. Include your own setup notes, testing evidence, commit IDs, and acknowledgement of AI assistance.
